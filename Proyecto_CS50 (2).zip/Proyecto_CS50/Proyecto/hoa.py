import random
import string

def generar_contraseña(longitud=8):
    caracteres = string.ascii_letters + string.digits
    contraseña = ''.join(random.choice(caracteres) for i in range(longitud))
    return contraseña

# Generar y mostrar la contraseña
print("Contraseña generada:", generar_contraseña())
